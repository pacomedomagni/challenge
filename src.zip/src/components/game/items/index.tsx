import Ghost from './Ghost';
import Pill from './Pill';
import Biscuit from './Biscuit';
import Pacman from './Pacman';

export { Pacman, Ghost, Pill, Biscuit };